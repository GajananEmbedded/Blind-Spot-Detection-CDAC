# Car-Blind-Spot-Detection-System
How light turns on and make noise at certain distance. 
